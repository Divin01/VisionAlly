// config.js  (project root — replace with your real keys)
// ─────────────────────────────────────────────────────────────────────────────
// NEVER commit this file with real keys in a public repo.
// Add config.js to .gitignore if you haven't already.
// ─────────────────────────────────────────────────────────────────────────────

const CONFIG = {
  // ── Adzuna Jobs API ───────────────────────────────────────────────────────
  // Register free at: https://developer.adzuna.com/
  // No credit card needed · Free: 250 calls/day
  // Create an app → copy App ID + App Key below
  ADZUNA_APP_ID:  'a72ab73b',
  ADZUNA_APP_KEY: 'fe4538308cc3197d105539c6a63eda83',
};

export default CONFIG;

/*
═══════════════════════════════════════════════════════════════════════════════
  GEMINI LIVE API — SETUP & DEBUGGING GUIDE
═══════════════════════════════════════════════════════════════════════════════

  YOUR ERROR:
  "models/gemini-2.5-live is not found for API version v1beta"

  ROOT CAUSE:
  The model name "gemini-2.5-live" does not exist. You must have changed it
  manually in GeminiLiveService.js. The correct model names are:

    ✅  gemini-2.0-flash-exp          ← Use this (stable for prototyping)
    ✅  gemini-live-2.5-flash         ← Use this (latest, from docs)
    ❌  gemini-2.5-live               ← Does NOT exist (your current value)
    ❌  gemini-live-2.5               ← Does NOT exist
    ❌  gemini-2.5-flash-live         ← Does NOT exist

  FIX (in GeminiLiveService.js, line ~11):
    const GEMINI_MODEL = 'gemini-2.0-flash-exp';   // ← Use this

═══════════════════════════════════════════════════════════════════════════════
  STEP-BY-STEP: ENABLE GEMINI LIVE API
═══════════════════════════════════════════════════════════════════════════════

  Step 1 — Get the RIGHT API key
  ┌─────────────────────────────────────────────────────────────────────────┐
  │  Go to: https://aistudio.google.com/app/apikey                         │
  │  Click "Create API key" → Select a Google Cloud project (or create one)│
  │  Copy the key — it starts with "AIza..."                               │
  │                                                                         │
  │  ⚠️  DO NOT use a key from Google Cloud Console API credentials.       │
  │      AI Studio keys have Live API access by default.                   │
  └─────────────────────────────────────────────────────────────────────────┘

  Step 2 — Enable the Generative Language API
  ┌─────────────────────────────────────────────────────────────────────────┐
  │  Go to: https://console.cloud.google.com/apis/library                  │
  │  Search: "Generative Language API"                                      │
  │  Click Enable (if not already enabled for your project)                │
  └─────────────────────────────────────────────────────────────────────────┘

  Step 3 — Verify Live API access in AI Studio
  ┌─────────────────────────────────────────────────────────────────────────┐
  │  Go to: https://aistudio.google.com/                                   │
  │  Click "New Stream" → choose Gemini 2.0 Flash                         │
  │  If it loads the audio stream, your key has Live API access.           │
  └─────────────────────────────────────────────────────────────────────────┘

  Step 4 — Update GeminiLiveService.js
  ┌─────────────────────────────────────────────────────────────────────────┐
  │  // Line 11 — correct model:                                            │
  │  const GEMINI_MODEL = 'gemini-2.0-flash-exp';                          │
  │                                                                         │
  │  // The WebSocket URL must remain:                                      │
  │  wss://generativelanguage.googleapis.com/ws/                            │
  │    google.ai.generativelanguage.v1beta.GenerativeService               │
  │    .BidiGenerateContent?key=YOUR_KEY                                    │
  └─────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
  FIRESTORE DATA NOT APPEARING — EXPLANATION
═══════════════════════════════════════════════════════════════════════════════

  Your About Me data IS being saved — you just can't find it in the console.

  The path is:  users / {uid} / profile / about_me

  In Firestore Console:
    1. Open the Firestore Database section
    2. Click the "users" collection
    3. Click on the document matching your user UID
    4. You will see "profile" listed as a SUBCOLLECTION under that document
       (subcollections appear below the document fields, in a separate section)
    5. Click "profile" → you'll see the "about_me" document with all your data

  Why it looks empty:
    The users/{uid} document itself may only have displayName, email etc.
    The About Me data lives in the SUBCOLLECTION: users/{uid}/profile/about_me

  Your Firestore rules are correct:
    match /users/{userId}/{document=**} { ... }  ← covers subcollections ✅

═══════════════════════════════════════════════════════════════════════════════
  EXPO-AV DEPRECATION WARNING (SDK 53/54)
═══════════════════════════════════════════════════════════════════════════════

  WARN: "Expo AV has been deprecated and will be removed in SDK 54."

  For now (SDK 53): expo-av still works — ignore the warning.

  When you're ready to upgrade (after the prototype):
    npx expo install expo-audio expo-video
  Then replace Audio imports with expo-audio equivalents.
  This is NOT causing any current bugs.

═══════════════════════════════════════════════════════════════════════════════
  ADZUNA API — QUICK SETUP
═══════════════════════════════════════════════════════════════════════════════

  1. Register at https://developer.adzuna.com/ (free, 2 minutes)
  2. Verify your email
  3. Click "Create App" in the dashboard
     - App Name: "VisionAlly"
     - App Type: Mobile
  4. Copy:
     - Application ID  → ADZUNA_APP_ID in config.js
     - Application Key → ADZUNA_APP_KEY in config.js
  5. Free tier: 250 requests/day (more than enough for prototype demos)

  Test the API works:
  https://api.adzuna.com/v1/api/jobs/za/search/1?app_id=YOUR_ID&app_key=YOUR_KEY&results_per_page=3&what=developer
  → Paste into browser — you should see JSON job listings.

═══════════════════════════════════════════════════════════════════════════════
*/